import {  Outlet,} from 'react-router-dom';
import { Container } from '@chakra-ui/react';
import Home from './Home/Home';

const Mainpage = () => {
 

  return (
    <>
    
    <Home />
   
    </>
  );
};

export default Mainpage;